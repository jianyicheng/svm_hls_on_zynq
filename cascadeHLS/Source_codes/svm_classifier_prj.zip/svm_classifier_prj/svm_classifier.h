

#ifndef _SVM_CLASSIFIER_H_
#define _SVM_CLASSIFIER_H_

#include "svm_data_type.h"
#define DIMENSION 16
#define CH_NUM 18
#define ALPHA_NUM 1050
#define TH_HIGH 130
#define TH_LOW -1
#define TH_HIGH_M 99
#define TH_LOW_M 0
#define MULT_LUT_NUM 0
#define LP_SCALE 525

void dotProduct(data15_4t x[DIMENSION], data13_4t y[DIMENSION], data16_7t *out);
void getKernel(data15_4t x[DIMENSION], data13_4t y[DIMENSION], data8_3t *out);
bool svm_classifier(data_t in[DIMENSION], int *lp_count, int *hp_count);
void svm_classifier_process(data13_4t s_in[DIMENSION], data15_4t SV_in[350][16], data13_5t alpha_in[LP_SCALE], data18_10t* out);

#endif

